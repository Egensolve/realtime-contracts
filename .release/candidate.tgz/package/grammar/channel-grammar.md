# Channel grammar

ERS exposes four versioned channel shapes:

```text
private-v1.tenants.{tenant}.accounts.{actor_type}.{actor_id}
private-v1.tenants.{tenant}.devices.{device_id}
presence-v1.tenants.{tenant}.rooms.{room_id}
private-v1.tenants.{tenant}.system
```

Every placeholder is non-empty ASCII and contains only letters, digits, `_`, or `-`. Dots are
separators and are never permitted inside a placeholder. A complete channel is at most 164
characters. Clients must construct one of these exact shapes and reject unknown prefixes, extra or
missing segments, empty placeholders, non-ASCII text, and disallowed punctuation.

Channel names identify delivery scopes. They do not grant access. A client subscribes only after
obtaining authorization from its application backend.
