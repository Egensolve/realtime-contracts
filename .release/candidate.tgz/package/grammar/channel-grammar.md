# Channel grammar

ERS exposes four v1 channel shapes and one private v2 Calls shape:

```text
private-v1.tenants.{tenant}.accounts.{actor_type}.{actor_id}
private-v1.tenants.{tenant}.devices.{device_id}
presence-v1.tenants.{tenant}.rooms.{room_type}.{room_id}
private-v1.tenants.{tenant}.systems.{scope}
private-v2.tenants.{tenant}.calls.{call_id}
```

Tenant, actor, device and room identifiers are 1–64 ASCII letters, digits, `_`, or `-`; call
identifiers use the same characters with a 1–128 character bound. Identifier case is preserved.
`actor_type`, `room_type` and `scope` are 1–32 character lowercase ASCII tokens: start with a
letter, then letters/digits or hyphen-separated non-empty groups of letters/digits. They cannot
start or end with a hyphen, contain consecutive hyphens, underscores or uppercase letters.

Dots are separators and are never permitted inside a placeholder. A complete channel, including
its prefix, is at most 164 characters even when each individual identifier fits its own bound.
`private-v2` supports only Calls; it does not accept v1 resources. Calls cannot use `private-v1`
or `presence-v1`. Clients must construct one of these exact shapes and reject unknown prefixes,
extra or missing segments, empty placeholders, non-ASCII text, and disallowed punctuation.

Channel names identify delivery scopes. They do not grant access. A client subscribes only after
obtaining authorization from its application backend.

The synthetic conformance cases in `../fixtures/channels/cases.json` include valid and invalid
Calls channels alongside the existing v1 cases. The v2 channel prefix does not change the version-1
envelope format.
