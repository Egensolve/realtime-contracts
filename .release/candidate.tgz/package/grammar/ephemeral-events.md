# Client-originated ephemeral events

Clients publish short-lived interaction signals through the authenticated ephemeral-event HTTP
endpoint. They do not send arbitrary socket client events.

The request contains the current `socket_id`, an authorized channel, optional signed
`channel_data`, and a version 1 ephemeral envelope. The envelope must include `expires_at`, must not
include recovery metadata, must be no larger than 2,048 UTF-8 bytes, and may expire no more than 30
seconds after `occurred_at`.

The initial public event types are:

- `presence.typing.started`
- `presence.typing.stopped`

Servers may return bounded error codes including `invalid_request`, `invalid_channel`,
`invalid_authorization`, `invalid_envelope`, `expired`, `rate_limited`, and `unavailable`. Unknown
event types are ignored by compatible consumers.
