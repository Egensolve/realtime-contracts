# Channel authorization grammar

An application backend authorizes a socket for one channel. The client sends the backend the exact
`socket_id` assigned to its connection and the exact channel name it intends to subscribe to.

For a private channel, the authorization value is:

```text
{application_key}:{hex_hmac_sha256(application_secret, socket_id + ":" + channel_name)}
```

For a presence channel, the backend also supplies compact JSON `channel_data` and signs:

```text
socket_id + ":" + channel_name + ":" + channel_data
```

The response contains `auth` and, for presence channels, the exact signed `channel_data` string.
Clients treat these values as opaque and must not log credentials or authorization responses.

`socket_id` is at most 64 characters. `channel_data` is a JSON object serialized to at most 1,024
UTF-8 bytes. A product backend decides whether its authenticated user may access the requested
channel; ERS does not define product users or roles.
