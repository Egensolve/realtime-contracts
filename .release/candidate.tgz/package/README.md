# ERS realtime contracts

This package contains the language-neutral wire contract needed to build an ERS realtime client:

- versioned envelope and error schemas;
- private and presence channel grammar;
- channel-authorization inputs and response grammar;
- client-originated ephemeral-event rules;
- bounded protocol limits; and
- synthetic conformance fixtures.

The package contains data and documentation only. Applications should use their language SDK's
validator where one is available, or validate the JSON schemas and the additional limits described
in `limits.md`.

Unknown envelope fields and unknown event types are forward-compatible within protocol version 1.
Consumers ignore what they do not understand while continuing to enforce the structural and size
limits in this package.

## License

MIT. See [LICENSE](LICENSE).

## Intelligence package candidate

This is an unreleased candidate. Machine credentials remain on trusted backends. Content uses
private Media, control requests contain references only, and generated text is untrusted.
Profile/job polling, deadlines, cancellation, output expiry and applying results remain caller-owned.

The `intelligence` directory describes the four private Media JSON content formats. The `schema/intelligence-*.v1.schema.json` files validate documents; content never enters control requests.
