# Protocol limits

These are hard client-facing input and transport limits. Producers should remain below them and
consumers must reject values that exceed them.

| Value | Maximum |
| --- | ---: |
| Channel name | 164 characters |
| Serialized envelope | 10,240 bytes |
| Envelope `tenant` | 128 characters |
| Envelope `domain` | 64 characters |
| Envelope `type` | 128 characters |
| Subject `type` | 64 characters |
| Subject `id` | 128 characters |
| Authorization `socket_id` | 64 characters |
| Serialized presence `channel_data` | 1,024 bytes |
| Client-originated ephemeral envelope | 2,048 bytes |
| Client-originated ephemeral expiry horizon | 30 seconds |

Envelope size is measured as UTF-8 bytes after JSON serialization. Payloads must be JSON objects.
Binary content, base64 blobs, data URIs, file bytes, audio, video, and attachments are not valid
realtime envelope content. Send an opaque identifier or public-safe metadata and transfer bytes
through the service intended for that purpose.
