# Version policy

The package version and the wire-protocol version are independent.

- Package patch releases may clarify documentation, add compatible fixtures, or fix validators.
- Package minor releases may add optional APIs or additive protocol material.
- Package major releases may change the package's consumer-facing layout or compatibility floor.
- The envelope `version` changes only for a breaking wire-contract change.

Protocol version 1 is additive. Producers may add fields and event types. Compatible consumers
ignore unknown fields and unknown event types while continuing to enforce known structural and size
rules. A field's meaning cannot change incompatibly within version 1.
