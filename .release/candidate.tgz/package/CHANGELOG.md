# Changelog

## 0.1.2

- License this public package under MIT.
- Limit the distribution to the documented protocol schemas, grammar and synthetic fixtures.

## 0.1.1

- Publish the version 1 envelope and error schemas.
- Publish channel, authorization, and ephemeral-event grammar.
- Publish protocol limits and synthetic conformance fixtures.
